package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;

public class IndexSliceToTime extends UDF {
    /**
     * 将时间片序号转换为时间
     * @param index
     * @param tp
     * @return
     */
        public String evaluate(String index,Long tp) {
        String hour = String.valueOf((Integer.valueOf(index) * tp / 60));
        if(hour.length() <= 1){
            hour = "0" + hour;
        }

        String minute = String.valueOf((Integer.valueOf(index) * tp % 60));
        if(minute.length() <= 1){
            minute = "0" + minute;
        }

        return hour + ":" + minute;
    }

    public static void main(String[] args) {
//        IndexSliceToTime indexSliceToTime=new IndexSliceToTime();
//        String s = indexSliceToTime.evaluate("9",30L);
//        System.out.println(s);
        TimeToDayPeriod timeToDayPeriod=new TimeToDayPeriod();
        timeToDayPeriod.evaluate("02:30");
    }
}
