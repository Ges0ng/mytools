package com.aliyun.publictransport.odps.udf;


import com.aliyun.odps.udf.UDF;


public class SphereDistance extends UDF {
    /**
     * 计算两点球面距离
     * @param lng1
     * @param lat1
     * @param lng2
     * @param lat2
     * @return
     */
    public Double evaluate(Double lng1, Double lat1, Double lng2, Double lat2){
        if(lng1==null||lat1==null||lng2==null||lat2==null){
            return null;
        }
        double dlng = (lng2 - lng1) * Math.PI / 180.0;
        double dlat = (lat2 - lat1) * Math.PI / 180.0;

        double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlng/2), 2);
        double distance = 2 * Math.asin(Math.sqrt( a )) * 6371 * 1000;
        return distance;
    }
    public static void main(String[] args){
        System.out.println(new SphereDistance().evaluate(113.54026794433594	,34.76829528808594,	113.61305236816406	,34.73670959472656

));
    }
}
