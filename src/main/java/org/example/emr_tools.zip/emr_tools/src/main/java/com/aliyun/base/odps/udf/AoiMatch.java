package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDF;
import com.aliyun.odps.udf.UDFException;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * tools-udf
 * odps.udf
 *
 * @author Feijue
 * @date 2020-12-21
 */
public class AoiMatch extends UDF {
    private Map<String, String> geohashMap = new HashMap<>();

    @Override
    public void setup(ExecutionContext ctx) throws UDFException {
        try {
            Iterator<Object[]> iterator = ctx.readResourceTable("resource_bas_rdnet_tfcunit_410100_01").iterator();
            while (iterator.hasNext()) {
                Object[] objects = iterator.next();


                String[] geohashList = ((String)objects[4]).split(",");
                String zoneType = (String)objects[2];
                String tfcunitId = (String)objects[0];

                if(zoneType.equals("0101")){
                    for(int i=0; i<geohashList.length; i++){
                        geohashMap.put(geohashList[i], tfcunitId);
                    }
                }
            }
        } catch (IOException e) {
            throw new UDFException(e);
        }
    }

    /**
     * 区域匹配
     */
    public String evaluate(String geohash, String level) {
        String small = "";
        if(geohashMap.containsKey(geohash)){
            small = geohashMap.get(geohash);
        }

        if(small.length() < 1){
            return null;
        }

        if(level.equals("0101")){
            return small;
        }
        if(level.equals("0102")){
            return small.substring(0, 4);
        }
        if(level.equals("0103")){
            return small.substring(0, 2);
        }
        return small;
    }
}
