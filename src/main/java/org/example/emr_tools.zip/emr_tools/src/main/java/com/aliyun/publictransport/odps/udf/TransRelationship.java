package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TransRelationship extends UDF {
    /**
     *  判断接驳换乘关系
     * @param tranship_station
     * @param rail_station
     * @param bus_station
     * @return 1代表公交轨交都为起始点，2公交轨交只有一方为起始点，3接驳点的上下两站连线无交点且上下两站点互相两点距离大于500m，4非其他三种
     */
    public String evaluate(String tranship_station,String rail_station,String bus_station){
        List<String> stationList= Arrays.asList(tranship_station.split(";"));
        List<String> railList= Arrays.asList(rail_station.split(";"));
        List<String> busList= Arrays.asList(bus_station.split(";"));
        Boolean israilstart=false;
        Boolean isbustart=false;
        for (String stations:stationList){
            if((Integer.valueOf(stations.split(",")[0])==1||Integer.valueOf(stations.split(",")[0])==railList.size())){
                if ((Integer.valueOf(stations.split(",")[1])==1||Integer.valueOf(stations.split(",")[1])==busList.size())){
                    return "1";
                }else {
                    israilstart=true;
                }
            }
            if((Integer.valueOf(stations.split(",")[1])==1||Integer.valueOf(stations.split(",")[1])==busList.size())){
                if ((Integer.valueOf(stations.split(",")[0])==1||Integer.valueOf(stations.split(",")[0])==railList.size())){
                    return "1";
                }else {
                    isbustart=true;
                }
            }
        }
        if(israilstart||isbustart){
            return "2";
        }
        for(String stations:stationList){
            if(!ifTrans(stations,railList,busList)){
                return "3";
            }
        }
        return "4";
    }
    public boolean ifTrans(String tranStation,List<String> railList,List<String> busList){
        int railSeq=Integer.valueOf(tranStation.split(",")[0]);
        int busSeq=Integer.valueOf(tranStation.split(",")[1]);
        String rail1=railList.get(railSeq-2);
        String rail2=railList.get(railSeq);
        String bus1=busList.get(busSeq-2);
        String bus2=busList.get(busSeq);
        if (!isIntersection(rail1,rail2,bus1,bus2)){
            if(new SphereDistance().evaluate(Double.valueOf(rail1.split(",")[0]),Double.valueOf(rail1.split(",")[1]),Double.valueOf(bus1.split(",")[0]),Double.valueOf(bus1.split(",")[1]))<=500||
                    new SphereDistance().evaluate(Double.valueOf(rail1.split(",")[0]),Double.valueOf(rail1.split(",")[1]),Double.valueOf(bus2.split(",")[0]),Double.valueOf(bus2.split(",")[1]))<=500){
                return false;
            }
            if(new SphereDistance().evaluate(Double.valueOf(rail2.split(",")[0]),Double.valueOf(rail2.split(",")[1]),Double.valueOf(bus1.split(",")[0]),Double.valueOf(bus1.split(",")[1]))<=500||
                    new SphereDistance().evaluate(Double.valueOf(rail2.split(",")[0]),Double.valueOf(rail2.split(",")[1]),Double.valueOf(bus2.split(",")[0]),Double.valueOf(bus2.split(",")[1]))<=500){
                return false;
            }
            return true;
        }
        return false;
    }
    public boolean isIntersection(String rail1,String rail2,String bus1,String bus2){
        double r,s;
        double deno = (Double.valueOf(rail2.split(",")[0]) -Double.valueOf(rail1.split(",")[0]) ) * (Double.valueOf(bus2.split(",")[1]) -Double.valueOf(bus2.split(",")[1])) - (Double.valueOf(rail2.split(",")[1]) -Double.valueOf(rail1.split(",")[1])) * (Double.valueOf(bus2.split(",")[0]) -Double.valueOf(bus2.split(",")[0]));
        double mem1 = (Double.valueOf(rail1.split(",")[1]) - Double.valueOf(bus1.split(",")[1])) * (Double.valueOf(bus2.split(",")[0]) - Double.valueOf(bus1.split(",")[0])) - (Double.valueOf(rail1.split(",")[0]) - Double.valueOf(bus1.split(",")[0])) * (Double.valueOf(bus2.split(",")[1]) - Double.valueOf(bus1.split(",")[1]));
        double mem2 = (Double.valueOf(rail1.split(",")[1]) - Double.valueOf(bus1.split(",")[1])) * (Double.valueOf(rail2.split(",")[0]) - Double.valueOf(rail1.split(",")[0])) - (Double.valueOf(rail1.split(",")[0]) - Double.valueOf(bus1.split(",")[0])) * (Double.valueOf(rail2.split(",")[1]) - Double.valueOf(rail1.split(",")[1]));
        r = mem1 / deno;
        s = mem2 / deno;
        if (r > 1 || r < 0){
            return false;
        }
        if (s > 1 || s < 0){
            return false;
        }
        return true;
    }
}
