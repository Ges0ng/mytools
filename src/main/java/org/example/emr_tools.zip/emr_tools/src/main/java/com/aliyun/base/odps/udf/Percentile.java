package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * tools-udf
 * odps.udf
 *
 * @author Feijue
 * @date 2020-12-21
 */
public class Percentile extends UDF {
    public Double evaluate(String loadStr, Double percent){
        if(StringUtils.isEmpty(loadStr)   || percent < 0 || percent > 1) {
            return null;
        }

        List<Double> loadList = new ArrayList<>();
        for(int i=0; i<loadStr.split(",").length; i++){
            loadList.add(Double.valueOf(loadStr.split(",")[i]));
        }
        Collections.sort(loadList);



        int n = loadList.size();
        double px =  percent * (n - 1);
        int i = (int) Math.floor(px);
        double g = px - i;
        if(g == 0){
            return loadList.get(i);
        }else{
            return (1 - g) * loadList.get(i) + g * loadList.get(i+1);
        }
    }

    public static void main(String[] args) {
        String loadStr = "1,2,3,4,5,6,7,10";
        double percent = 0.5;
        Percentile percentile = new Percentile();
        System.out.println(percentile.evaluate(loadStr, percent));
    }
}
