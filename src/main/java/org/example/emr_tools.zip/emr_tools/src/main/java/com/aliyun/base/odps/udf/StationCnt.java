package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;
import com.aliyun.publictransport.odps.udf.SphereDistance;

/**
 * 计算接驳站点个数(距离相差50米内判断为一个站点)
 */
public class StationCnt extends UDF {
    public String evaluate(String str){
        String[] strs=str.split(";");
        int cnt=0;
        for(int i=0;i<strs.length;i++){
            int flag=0;
            for (int j=i+1;j<strs.length;j++){
                if(Double.valueOf(new SphereDistance().evaluate(Double.valueOf(strs[i].split(",")[0]),Double.valueOf(strs[i].split(",")[1]),Double.valueOf(strs[j].split(",")[0]),Double.valueOf(strs[j].split(",")[1])))<50){
                    flag=0;
                    break;
                }else {
                    if(i==strs.length-2){
                        cnt++;
                    }
                    flag=1;
                }
            }
            if (flag==1){
                cnt++;
            }
        }
        if (cnt==0){
            return "2";
        }
        cnt=cnt*2;
        return String.valueOf(cnt);
    }
}
