package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;

public class TimeToIndex extends UDF {
    public String evaluate(String time){
        if(Integer.valueOf(time)>=40||Integer.valueOf(time)<0){
            return "9";
        }
        return Integer.valueOf(time)/10+"";
    }
}
