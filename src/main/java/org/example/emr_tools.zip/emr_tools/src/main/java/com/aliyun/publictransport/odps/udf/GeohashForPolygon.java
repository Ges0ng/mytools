package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import com.jillesvangurp.utils.GeoGeometryUtils;
import org.apache.commons.lang.StringUtils;


import java.util.*;

public class GeohashForPolygon extends UDF {
    public static final String GEOMETRY_POLYGON = "POLYGON";
    public static final String GEOMETRY_MULTIPOLYGON = "MULTIPOLYGON";

    public static final Long TYPE_INCLUDED = 0L;
    public static final Long TYPE_INCLUDE = 1L;
    public static final Long TYPE_PATH = 2L;

    /**
     * 将区域边界经纬度串转换为geohash串
     * @param polygon
     * @param geohashLength
     * @param type
     * @return
     */
    public Set<String> getGeoHashes(String polygon, Long geohashLength, Long type) {
        String[] cols = polygon.split("\\),\\(");
        if (cols.length == 1) {
            Set<String> geohashes = new HashSet<String>();
            if (type.equals(TYPE_INCLUDE)) {
                geohashes = GeoGeometryUtils.geoHashesForPolygonInclude(polygon, geohashLength.intValue());
            } else if (type.equals(TYPE_PATH)) {
                geohashes = GeoGeometryUtils.geoHashesForPolygonPath(polygon, geohashLength.intValue());
            } else {
                geohashes = GeoGeometryUtils.geoHashesForPolygonIncluded(polygon, geohashLength.intValue());
            }
            return geohashes;
        } else {
            Set<String> geohashes = new HashSet<String>();
            if (type.equals(TYPE_INCLUDE)) {
                geohashes = GeoGeometryUtils.geoHashesForPolygonInclude(cols[0], geohashLength.intValue());
                for (int i = 1; i < cols.length; i++) {
                    Set<String> inside = GeoGeometryUtils.geoHashesForPolygonIncluded(cols[i], geohashLength.intValue());
                    geohashes.removeAll(inside);
                }
            } else if (type.equals(TYPE_PATH)) {
                geohashes = GeoGeometryUtils.geoHashesForPolygonPath(cols[0], geohashLength.intValue());
                for (int i = 1; i < cols.length; i++) {
                    Set<String> inside = GeoGeometryUtils.geoHashesForPolygonPath(cols[i], geohashLength.intValue());
                    geohashes.addAll(inside);
                }
            } else {
                geohashes = GeoGeometryUtils.geoHashesForPolygonIncluded(cols[0], geohashLength.intValue());
                for (int i = 1; i < cols.length; i++) {
                    Set<String> inside = GeoGeometryUtils.geoHashesForPolygonInclude(cols[i], geohashLength.intValue());
                    geohashes.removeAll(inside);
                }
            }
            return geohashes;
        }
    }

    /**
     *
     * @param polygon
     *            polygon的格式 POLYGON((120.357941 30.318445,120.357929 30.317364,120.355962 30.317368,120.35593 30.318572,120.357769 30.318575,120.357864 30.318559,120.357924 30.318514,120.357941 30.318445))
     * @param geohashLength
     *            geohash的长度
     * @param type
     *            0 默认，代表取被包含的geohash列表；1 代表包含的geohash列表；2代表边界的geohash列表
     * @return
     */
    public String evaluate(String polygon, Long geohashLength, Long type) {
        Set<String> geohashes = new HashSet<String>();
        if (polygon.startsWith(GEOMETRY_POLYGON)) {
            geohashes = getGeoHashes(polygon, geohashLength, type);
        } else if (polygon.startsWith(GEOMETRY_MULTIPOLYGON)) {
            String[] polygonTmps = polygon.replace("MULTIPOLYGON(((", "((").replace(")))", "))").split("\\)\\),\\(\\(");
            for (String polygonTmp : polygonTmps) {
                geohashes.addAll(getGeoHashes(polygonTmp, geohashLength, type));
            }
        } else {
            return null;
        }
        return StringUtils.join(geohashes, ",");
    }

    public static void main(String[] args) {
        GeohashForPolygon geohashForPolygon = new GeohashForPolygon();

        String p1 = "POLYGON((104.13833141326904 30.633647145661946,104.13451194763184 30.625800008904292,104.14270877838133 30.622402462905523,104.14588451385498 30.6304160487695,104.13833141326904 30.633647145661946))";
        String p2 = "POLYGON((103.95486831665039 30.59861630209901,103.93392562866211 30.55353955112072,103.9610481262207 30.54407816393645,103.97392272949219 30.59285355813393,103.95486831665039 30.59861630209901))";
        String p3 = "POLYGON((103.94628524780273 30.59965060448085,103.91693115234375 30.5143575005325,103.9442253112793 30.50607549756194,103.98078918457031 30.593444624569656,103.94628524780273 30.59965060448085))";

        String polygon = "POLYGON((103.94628524780273 30.59965060448085,103.91693115234375 30.5143575005325,103.9442253112793 30.50607549756194,103.98078918457031 30.593444624569656,103.94628524780273 30.59965060448085))";
        System.out.println(polygon);
        String ret1 = geohashForPolygon.evaluate(polygon, 7L, 0L);
        String ret2 = geohashForPolygon.evaluate(polygon, 7L, 1L);
        String ret3 = geohashForPolygon.evaluate(polygon, 7L, 2L);
        System.out.println(ret1.split(",").length);
        System.out.println(ret1);
        System.out.println(ret2.split(",").length);
        System.out.println(ret2);
        System.out.println(ret3.split(",").length);
        System.out.println("-------------------------");



        String geohash3 = geohashForPolygon.evaluate(p3, 7L, 0L);
        System.out.println(geohash3.contains("wm3ynk9"));
    }

}
