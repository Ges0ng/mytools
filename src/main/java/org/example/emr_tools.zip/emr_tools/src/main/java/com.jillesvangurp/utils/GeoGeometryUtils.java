package com.jillesvangurp.utils;

import com.jillesvangurp.geo.GeoGeometry;

import java.util.HashSet;
import java.util.Set;

/**
 * @author: peikun.lpk
 * @create: 2019-07-31 16:29
 * @description: GeoGeometryUtils工具类
 */
public class GeoGeometryUtils {
    /**
     * 计算Polygon被包含的geohash列表，包括包含的geohash和边界geohash
     * 
     * @param polygon
     * @param geohashLength
     * @return
     */
    public static Set<String> geoHashesForPolygonIncluded(String polygon, int geohashLength) {
        Set<String> geohashPolygonInclude = GeoGeometryUtils.geoHashesForPolygonInclude(polygon, geohashLength);
        Set<String> geohashPolygonPath = GeoGeometryUtils.geoHashesForPolygonPath(polygon, geohashLength);
        Set<String> geohashPolygonIncluded = new HashSet<String>();
        geohashPolygonIncluded.addAll(geohashPolygonInclude);
        geohashPolygonIncluded.addAll(geohashPolygonPath);
        return geohashPolygonIncluded;
    }
    
    /**
     * 计算Polygon包含的geohash列表
     * 
     * @param polygon
     * @param geohashLength
     * @return
     */
    public static Set<String> geoHashesForPolygonInclude(String polygon, int geohashLength) {
        String[] points = polygon.replace("POLYGON((", "").replace("((", "").replace("))", "").split(",");
        double[][] polygonPoints = new double[points.length][2];
        for (int i = 0; i < points.length; i++) {
            String[] point = points[i].split(" ");
            polygonPoints[i][0] = Double.parseDouble(point[0]);
            polygonPoints[i][1] = Double.parseDouble(point[1]);
        }
        
        Set<String> geohashsPolygon = GeohashUtilsTool.geoHashesForPolygon(geohashLength, false, polygonPoints);
        Set<String> geohashsTmp = new HashSet<String>();
        for (String geohash : geohashsPolygon) {
            if (geohash.length() == geohashLength) {
                geohashsTmp.add(geohash);
            } else {
                String[] geohashs = GeohashUtilsTool.subHashes(geohash, geohashLength);
                for (String geohashStr : geohashs) {
                    geohashsTmp.add(geohashStr.substring(0, geohashLength));
                }
            }
        }
        return geohashsTmp;
    }
    
    /**
     * 计算Polygon边界的geohash列表
     * 
     * @param polygon
     * @param geohashLength
     * @return
     */
    public static Set<String> geoHashesForPolygonPath(String polygon, int geohashLength) {
        String[] points = polygon.replace("POLYGON((", "").replace("((", "").replace("))", "").split(",");
        double[][] polygonPoints = new double[points.length][2];
        for (int i = 0; i < points.length; i++) {
            String[] point = points[i].split(" ");
            polygonPoints[i][0] = Double.parseDouble(point[1]);
            polygonPoints[i][1] = Double.parseDouble(point[0]);
        }
        
        Set<String> geohashsPath = GeohashUtilsTool.geoHashesForPath(geohashLength, polygonPoints);
        Set<String> geohashsTmp = new HashSet<String>();
        for (String geohash : geohashsPath) {
            geohashsTmp.add(geohash.substring(0, geohashLength));
        }
        return geohashsTmp;
    }
    
    /**
     * 计算polygon的bbox
     * 
     * @param polygon
     * @return
     */
    public static double[] boundingBox(String polygon) {
        String[] points = polygon.replace("POLYGON((", "").replace("((", "").replace("))", "").split(",");
        double[][] polygonPoints = new double[points.length][2];
        for (int i = 0; i < points.length; i++) {
            String[] point = points[i].split(" ");
            polygonPoints[i][0] = Double.parseDouble(point[0]);
            polygonPoints[i][1] = Double.parseDouble(point[1]);
        }
        
        return GeoGeometry.boundingBox(polygonPoints);
    }
}
