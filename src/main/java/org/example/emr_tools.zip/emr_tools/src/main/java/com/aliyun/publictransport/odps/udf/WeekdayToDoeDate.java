package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;


public class WeekdayToDoeDate extends UDF {
    /**
     * 判断日期是否为工作日
     * @param date
     * @return
     * @throws Exception
     */
    public String evaluate(String date) throws Exception {
        if(Integer.valueOf(date) < 5){
            return "99";
        } else {
            return "100";
        }
    }
}
