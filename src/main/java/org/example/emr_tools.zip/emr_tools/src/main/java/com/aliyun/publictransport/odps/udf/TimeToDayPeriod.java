package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;


public class TimeToDayPeriod extends UDF {
    /**
     * 判断时间是否为早晚高峰
     * @param date
     * @return
     */
    public String evaluate(String date) {
        if(StringUtils.isEmpty(date)){
            return null;
        }

//        if(date.compareTo("06:00") < 1){
////            return null;
////        }
        else if(date.compareTo("07:00") > -1 && date.compareTo("09:00") < 1){
            return "1";
        }
        else if(date.compareTo("18:00") > -1 && date.compareTo("20:00") < 1){
            return "3";
        } else {
            return "5";
        }
    }

    public static void main(String[] args) {
        System.out.println(new TimeToDayPeriod().evaluate("2021-03-03 08:00:00"));
        System.out.println("07:00".compareTo("07:00"));
    }
}
