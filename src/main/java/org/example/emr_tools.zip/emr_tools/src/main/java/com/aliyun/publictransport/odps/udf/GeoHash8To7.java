package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;

import java.util.LinkedHashSet;

public class GeoHash8To7 extends UDF {
    public String evaluate(String geohash){
        String[] geohash8=geohash.split(",");
        LinkedHashSet<String> set=new LinkedHashSet<>();
        for (String str:geohash8
             ) {
            set.add(str.substring(0,7));
        }
        return StringUtils.join(set,",");
    }

    public static void main(String[] args) {
        System.out.println(new GeoHash8To7().evaluate("geohash7,geohash8,geohash9,gaohash9,gcohash9"));
    }
}
