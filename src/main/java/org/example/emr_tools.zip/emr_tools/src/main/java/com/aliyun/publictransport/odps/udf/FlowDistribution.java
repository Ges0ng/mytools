package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;

import java.util.*;

public class FlowDistribution extends UDF {
    public String evaluate(String departDistribution, String arrivalDistribution) {
        if(StringUtils.isEmpty(departDistribution)){
            return arrivalDistribution;
        }
        if(StringUtils.isEmpty(arrivalDistribution)){
            return departDistribution;
        }
        Map<String, Integer> ret = new HashMap<>();
        String[] dep = departDistribution.split(";");
        for(int i=0; i<dep.length; i++){
            String time = dep[i].split(",")[0];
            int num = Integer.valueOf(dep[i].split(",")[1]);
            if(!ret.containsKey(time)){
                ret.put(time, 0);
            }
            ret.put(time, ret.get(time) + num);
        }

        String[] arr = arrivalDistribution.split(";");
        for(int i=0; i<arr.length; i++){
            String time = arr[i].split(",")[0];
            int num = Integer.valueOf(arr[i].split(",")[1]);
            if(!ret.containsKey(time)){
                ret.put(time, 0);
            }
            ret.put(time, ret.get(time) + num);
        }
        List<String> timeList = new ArrayList<>(ret.keySet());
        Collections.sort(timeList, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                if(o1.compareTo(o2) > 0){
                    return 1;
                }
                else if(o1.compareTo(o2) < 0){
                    return -1;
                }
                return 0;
            }
        });

        String res = "";
        for(int i=0; i<timeList.size(); i++){
            String time = timeList.get(i);
            if(i > 0){
                res += ";";
            }
            res += time + "," + ret.get(time);
        }
        return res;
    }

    public static void main(String[] args) {
        FlowDistribution flowDistribution = new FlowDistribution();
        String departDistribution = "06:00,10;07:00,20;08:00,5";
        String arrivalDistribution = "09:00,10;07:00,20;08:00,100";
        System.out.println(flowDistribution.evaluate(departDistribution, arrivalDistribution));
    }
}
