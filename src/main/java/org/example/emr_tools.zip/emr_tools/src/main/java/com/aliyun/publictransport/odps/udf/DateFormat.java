package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;

/**
 * EMR_Tools
 * com.aliyun.publictransport.emrTools.hive
 *
 * @author Feijue
 * @date 2020-06-22
 */
public class DateFormat extends UDF {
    /**
     * 时间格式化
     * @param date
     * @return
     * @throws Exception
     */
    public String evaluate(String date) throws Exception {
        if(StringUtils.isEmpty(date) && date.length() < 12){
            return null;
        }

        if(date.substring(10, 12).compareTo("30") > -1){
            return date.substring(8, 10) + "30";
        } else {
            return date.substring(8, 10) + "00";
        }
    }

}
