package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.ArrayUtils;

import java.util.Arrays;

public class Percent_inset extends UDF {
    public String evaluate(String str){
        String[] strs=str.split(",");
        System.out.println(ArrayUtils.toString(strs));
        if (strs.length==5){
            String result= Double.valueOf(strs[0])<=Double.valueOf(strs[1])?"25":(Double.valueOf(strs[0])<=Double.valueOf(strs[2])?"50":(Double.valueOf(strs[0])<=Double.valueOf(strs[3])?"75":"100")) ;
            return result+","+strs[0]+","+strs[1]+","+strs[2]+","+strs[3]+","+strs[4];
        }
        return null;
    }

    public static void main(String[] args) {
        System.out.println(new Percent_inset().evaluate("8960,14725.0,32202.0,57462.0,334048.0"));
        System.out.println(new Percent_inset().evaluate("63816,39194.0,81465.0,144234.0,857864.0"));
    }
}
