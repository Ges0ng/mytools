package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;


public class DepArrFlowFusion extends UDF {
    public Integer evaluate(String dep, String arr) {
        if(StringUtils.isEmpty(dep)){
            return Integer.valueOf(arr);
        }
        if(StringUtils.isEmpty(arr)){
            return Integer.valueOf(dep);
        }
        return Integer.valueOf(dep) + Integer.valueOf(arr);
    }

    public Integer evaluate(String dep, String arr, int mode) {
        if(StringUtils.isEmpty(dep)){
            return Integer.valueOf(arr);
        }
        if(StringUtils.isEmpty(arr)){
            return Integer.valueOf(dep);
        }
        return (Integer.valueOf(dep) + Integer.valueOf(arr))/ mode;
    }
}
