package com.aliyun.publictransport.odps.udf;


import ch.hsr.geohash.GeoHash;
import com.aliyun.odps.udf.UDF;


public class GeohashEncode extends UDF {
    /**
     * geohash编码
     * 将经纬度坐标转换为geohash字符串
     * @param longi
     * @param lati
     * @param length
     * @return
     */
    public String evaluate(Double longi, Double lati, Long length) {
        if (longi == null || lati == null) {
            return null;
        } else if (length == null) {
            length = 12L;
        }

        try {
            GeoHash hash = GeoHash.withCharacterPrecision(lati, longi, length.intValue());
            return hash.toBase32();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {

        }
    }

    public static void main(String[] args) {
//        GeohashEncode geohashEncode = new GeohashEncode();
//        String ret = geohashEncode.evaluate(-75.9375, 40.390943, 7L);
//        System.out.println(ret);
//        AreaCoorsCenter areaCoorsCenter=new AreaCoorsCenter();
//        System.out.println(areaCoorsCenter.evaluate("MULTIPOLYGON(((113.676818225759831 34.750682647811807,113.675963320979136 34.745879367284346,113.670571270484757 34.746631795024392,113.666608879595302 34.744726028714325,113.66657692237591 34.747343710790453,113.667793518753939 34.748317324644674,113.668106458213302 34.749742747657237,113.668256630345056 34.751476783212134,113.669987571999073 34.751905708615254,113.673051673100815 34.751394890407113,113.676818225759831 34.750682647811807)))"));
        String str = "00a0012sadas230";
    String newStr = str.replaceAll("^(0+)", "");
        System.out.println(newStr);
}

}
