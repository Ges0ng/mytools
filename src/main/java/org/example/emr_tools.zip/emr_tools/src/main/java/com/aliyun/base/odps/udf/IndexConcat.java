package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;

import java.util.*;

public class IndexConcat extends UDF {
    public String evaluate(String str,String flag){
        Map<String,Integer> map=new HashMap<String,Integer>();
        Map<String,Integer> map1=new HashMap<String,Integer>();
        String[] strs=str.split(";");
        for (String index:strs){
            if(map.containsKey(index.split(",")[0])){
                map.put(index.split(",")[0],map.get(index.split(",")[0])+Integer.valueOf(index.split(",")[1]));
                if(!flag.equals("1")){
                    map1.put(index.split(",")[0],map1.get(index.split(",")[0])+1);
                }
            }else {
                map1.put(index.split(",")[0],1);
                map.put(index.split(",")[0],Integer.valueOf(index.split(",")[1]));
            }
        }
        List<String> list=new ArrayList<>();
        Set set=map.entrySet();
        Map.Entry[] entrys=(Map.Entry[])set.toArray(new Map.Entry[set.size()]);
        for(Map.Entry entry:entrys){
            list.add(entry.getKey()+","+Math.round((double)Integer.valueOf((int)entry.getValue())/Integer.valueOf(map1.get(entry.getKey()))));
        }
//        fun1(map1);
        return StringUtils.join(list,";");
    }
    public static void main(String[] args) {
        System.out.println(new IndexConcat().evaluate("1,1;3,3;4,4;2,1;2,1;5,3;6,6;5,2;2,9","1"));
//        System.out.println(Math.round(11/3));
    }
}
