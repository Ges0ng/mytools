package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;

import java.util.regex.Pattern;

/**
 * 判断字符串是否为纯数字
 */
public class IsNumber extends UDF {
    public String evaluate(String str){
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        if(pattern.matcher(str).matches()){
            return "1";
        }
        return "0";
    }
}
