package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 实现各种格式日期转yyyy-MM-dd HH:mm:ss格式
 */
public class DateFormat extends UDF {
    public String evaluate(String timestr) {
        if (timestr == null) {
            return null;
        }
        timestr = timestr.trim();
        try {
            SimpleDateFormat simFormat = new SimpleDateFormat("yyyyMMdd");
            String srt1 = "^[1-9]\\d{3}/(0[1-9]|1[0-2]|[1-9])/([1-9]|0[1-9]|[1-2][0-9]|3[0-1])$";//yyyy/MM/dd
            String srt2 = "^[1-9]\\d{3}(0[1-9]|1[0-2])([1-9]|0[1-9]|[1-2][0-9]|3[0-1])$";//yyyyMMdd
            String srt3 = "^([1-9]\\d{3})-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[1-2][0-9]|3[0-1])$";//yyyy-MM-dd
            String srt4 = "^([1-9]\\d{3})(0[1-9]|1[0-2]|[1-9])(0[1-9]|[1-2][0-9]|3[0-1])([01]\\d|2[01234])([0-5]\\d|60)$";//yyyyMMddHHmm
            String srt5 = "^[1-9]\\d{3}/(0[1-9]|1[0-2]|[1-9])/([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]|[0-9]):([0-5][0-9]):([0-5][0-9])$";//yyyy/MM/dd HH:mm:ss
            String srt6 = "^[1-9]\\d{3}(0[1-9]|1[0-2])([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$";//yyyyMMdd HH:mm:ss
            String srt7 = "^([1-9]\\d{3})-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$";//yyyy-MM-dd HH:mm:ss
            String srt8 = "^[1-9]\\d{3}\\.(0[1-9]|1[0-2]|[1-9])\\.([1-9]|0[1-9]|[1-2][0-9]|3[0-1])$";//yyyy.MM.dd
            String srt9 = "^[1-9]\\d{3}\\.(0[1-9]|1[0-2]|[1-9])\\.([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$";//yyyy.MM.dd HH:mm:ss
            String srt10 = "^([1-9]\\d{3})-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9])$";//yyyy-MM-dd HH:mm
            String srt11 = "^[1-9]\\d{3}/(0[1-9]|1[0-2]|[1-9])/([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9])$";//yyyy/MM/dd HH:mm
            String srt12 = "^[1-9]\\d{3}(0[1-9]|1[0-2])([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9])$";//yyyyMMdd HH:mm
            String srt13 = "^[1-9]\\d{3}\\.(0[1-9]|1[0-2]|[1-9])\\.([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9])$";//yyyy.MM.dd HH:mm
            String srt14 = "^([1-9]\\d{3})-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]).(\\d{1,3})$";//yyyy-MM-dd HH:mm:ss.SSS
            String srt15 = "^[1-9]\\d{3}/(0[1-9]|1[0-2]|[1-9])/([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]).(\\d{1,3})$";//yyyy/MM/dd HH:mm:ss.SSS
            String srt16 = "^[1-9]\\d{3}(0[1-9]|1[0-2])([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]).(\\d{1,3})$";//yyyyMMdd HH:mm:ss.SSS
            String srt17 = "^[1-9]\\d{3}\\.(0[1-9]|1[0-2]|[1-9])\\.([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]).(\\d{1,3})$";//yyyy.MM.dd HH:mm:ss.SSS
            String srt19 = "^([1-9]\\d{3})-(0[1-9]|1[0-2]|[1-9])-([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\\s*([0-9]):([0-5][0-9]):([0-5][0-9])$";//yyyy-MM-dd HH:mm:ss

            String srt18 = "^([1-9]|0[1-9]|[1-2][0-9]|3[0-1])-(0[1-9]|1[0-2]|[1-9])月\\s*-\\d{2}$";    //16-5月 -14
            if (timestr.matches(srt1)) {
                Date date = new SimpleDateFormat("yyyy/MM/dd").parse(timestr);
                return simFormat.format(date);
            }
            if (timestr.matches(srt2)) {
                Date date = new SimpleDateFormat("yyyyMMdd").parse(timestr);
                return simFormat.format(date);
            }
            if (timestr.matches(srt3)) {
                Date date = new SimpleDateFormat("yyyy-MM-dd").parse(timestr);
                return simFormat.format(date);
            }
            if (timestr.matches(srt8)) {
                Date date = new SimpleDateFormat("yyyy.MM.dd").parse(timestr);
                return simFormat.format(date);
            }
            if(timestr.matches(srt4)){
                Date date = new SimpleDateFormat("yyyyMMddHHmm").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt5)){
                Date date = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt6)){
                Date date = new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt7)){
                Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt9)){
                Date date = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt10)){
                Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt11)){
                Date date = new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt12)){
                Date date = new SimpleDateFormat("yyyyMMdd HH:mm").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt13)){
                Date date = new SimpleDateFormat("yyyy.MM.dd HH:mm").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt14)){
                Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt15)){
                Date date = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt16)){
                Date date = new SimpleDateFormat("yyyyMMdd HH:mm:ss.SSS").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if(timestr.matches(srt17)){
                Date date = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss.SSS").parse(timestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }

            if (timestr.matches(srt18)) {
                String[] strs = timestr.split("-");
                String cathestr="20"+strs[2]+"-"+strs[1].trim().substring(0,strs[1].trim().length() - 1)+"-"+strs[0];
                Date date =new SimpleDateFormat("yyyy-MM-dd").parse(cathestr);
                simFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return simFormat.format(date);
            }
            if (timestr.matches(srt19)) {
                String[] strs = timestr.split(" ");
                String cathestr=strs[0]+" 0"+strs[1];
                return cathestr;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public static void main(String[] args) {
//        long startTime = System.currentTimeMillis();   //获取开始时间
        DateFormat dateFormat = new DateFormat();
        System.out.println(dateFormat.evaluate("2021/5/8 9:07:50"));
////        long count =0l;
////        for(int i=0;i<1600000;i++){
////            count++;
////        }
//        long endTime = System.currentTimeMillis(); //获取结束时间
//        System.out.println("程序运行时间： " + (endTime - startTime) + "ms");
////        CanCastNum canCastNum=new CanCastNum();
////        System.out.println(canCastNum.evaluate("20171019"));
//        StationCnt sphereDistance=new StationCnt();
//        System.out.println(sphereDistance.evaluate("113.54183553,34.73638665;113.54212322,34.73582067;113.541975,34.73601;113.54178971,34.73627231"));
    }
}
