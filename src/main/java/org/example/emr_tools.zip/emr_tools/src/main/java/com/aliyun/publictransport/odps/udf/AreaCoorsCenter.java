package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;

public class AreaCoorsCenter extends UDF {

    /**
     * 计算区域中心点坐标
     * @param boundPoly
     * @return
     */
    public String evaluate(String boundPoly) {
        boundPoly=boundPoly.replace("MULTIPOLYGON(((","").replace(")))","").replace(")),((",";");
        String[] boundPolys= boundPoly.split(";");
        ArrayList<String> centers=new ArrayList<>();
        for (String boundPoly1 : boundPolys) {
            double centerLng = 0.0D;
            double centerLat = 0.0D;
            int cnt = 0;
            String[] bounds = boundPoly1.split(",");

            for (String bound : bounds) {
                String[] coors = bound.split(" ");
                centerLng += Double.valueOf(coors[0]);
                centerLat += Double.valueOf(coors[1]);
                cnt += 1;
            }
            centers.add(centerLng / cnt + "," + centerLat / cnt);
        }
        return StringUtils.join(centers,";");
    }
}