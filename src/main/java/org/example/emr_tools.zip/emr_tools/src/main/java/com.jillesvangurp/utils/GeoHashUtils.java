package com.jillesvangurp.utils;

import com.jillesvangurp.utils.LineUtils;

import java.util.*;

public class GeoHashUtils {
    private static int DEFAULT_PRECISION;
    private static int[] BITS;
    private static char[] BASE32_CHARS;
    static final Map<Character, Integer> BASE32_DECODE_MAP;
    public static final char[][] GEOHASH_ENDINGS;

    public static String encode(final double latitude, final double longitude, final int length) {
        if (length < 1 || length > 12) {
            throw new IllegalArgumentException("length must be between 1 and 12");
        }
        GeoGeometry.validate(latitude, longitude);
        final double[] latInterval = {-90.0, 90.0};
        final double[] lonInterval = {-180.0, 180.0};
        final StringBuilder geohash = new StringBuilder();
        boolean isEven = true;
        int bit = 0;
        int ch = 0;
        while (geohash.length() < length) {
            double mid = 0.0;
            if (isEven) {
                mid = (lonInterval[0] + lonInterval[1]) / 2.0;
                if (longitude > mid) {
                    ch |= GeoHashUtils.BITS[bit];
                    lonInterval[0] = mid;
                } else {
                    lonInterval[1] = mid;
                }
            } else {
                mid = (latInterval[0] + latInterval[1]) / 2.0;
                if (latitude > mid) {
                    ch |= GeoHashUtils.BITS[bit];
                    latInterval[0] = mid;
                } else {
                    latInterval[1] = mid;
                }
            }
            isEven = !isEven;
            if (bit < 4) {
                ++bit;
            } else {
                geohash.append(GeoHashUtils.BASE32_CHARS[ch]);
                bit = 0;
                ch = 0;
            }
        }
        return geohash.toString();
    }

    public static String encode(final double latitude, final double longitude) {
        return encode(latitude, longitude, GeoHashUtils.DEFAULT_PRECISION);
    }

    public static String encode(final double[] point) {
        return encode(point[1], point[0], GeoHashUtils.DEFAULT_PRECISION);
    }

    public static double[] decode_bbox(final String geohash) {
        final double[] latInterval = {-90.0, 90.0};
        final double[] lonInterval = {-180.0, 180.0};
        boolean isEven = true;
        for (int i = 0; i < geohash.length(); ++i) {
            final int currentCharacter = GeoHashUtils.BASE32_DECODE_MAP.get(geohash.charAt(i));
            for (int z = 0; z < GeoHashUtils.BITS.length; ++z) {
                final int mask = GeoHashUtils.BITS[z];
                if (isEven) {
                    if ((currentCharacter & mask) != 0x0) {
                        lonInterval[0] = (lonInterval[0] + lonInterval[1]) / 2.0;
                    } else {
                        lonInterval[1] = (lonInterval[0] + lonInterval[1]) / 2.0;
                    }
                } else if ((currentCharacter & mask) != 0x0) {
                    latInterval[0] = (latInterval[0] + latInterval[1]) / 2.0;
                } else {
                    latInterval[1] = (latInterval[0] + latInterval[1]) / 2.0;
                }
                isEven = !isEven;
            }
        }
        return new double[]{latInterval[0], latInterval[1], lonInterval[0], lonInterval[1]};
    }

    public static double[] decode(final String geohash) {
        final double[] bbox = decode_bbox(geohash);
        final double latitude = (bbox[0] + bbox[1]) / 2.0;
        final double longitude = (bbox[2] + bbox[3]) / 2.0;
        return new double[]{longitude, latitude};
    }

    public static String north(final String geoHash) {
        final double[] bbox = decode_bbox(geoHash);
        final double latDiff = bbox[1] - bbox[0];
        final double lat = bbox[0] - latDiff / 2.0;
        final double lon = (bbox[2] + bbox[3]) / 2.0;
        return encode(lat, lon, geoHash.length());
    }

    public static String south(final String geoHash) {
        final double[] bbox = decode_bbox(geoHash);
        final double latDiff = bbox[1] - bbox[0];
        final double lat = bbox[1] + latDiff / 2.0;
        final double lon = (bbox[2] + bbox[3]) / 2.0;
        return encode(lat, lon, geoHash.length());
    }

    public static String west(final String geoHash) {
        final double[] bbox = decode_bbox(geoHash);
        final double lonDiff = bbox[3] - bbox[2];
        final double lat = (bbox[0] + bbox[1]) / 2.0;
        double lon = bbox[2] - lonDiff / 2.0;
        if (lon < -180.0) {
            lon = 180.0 - (lon + 180.0);
        }
        if (lon > 180.0) {
            lon = 180.0;
        }
        return encode(lat, lon, geoHash.length());
    }

    public static String east(final String geoHash) {
        final double[] bbox = decode_bbox(geoHash);
        final double lonDiff = bbox[3] - bbox[2];
        final double lat = (bbox[0] + bbox[1]) / 2.0;
        double lon = bbox[3] + lonDiff / 2.0;
        if (lon > 180.0) {
            lon = -180.0 + (lon - 180.0);
        }
        if (lon < -180.0) {
            lon = -180.0;
        }
        return encode(lat, lon, geoHash.length());
    }

    public static boolean contains(final String geoHash, final double latitude, final double longitude) {
        return GeoGeometry.bboxContains(decode_bbox(geoHash), latitude, longitude);
    }

    public static String[] subHashes(final String geoHash) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final char c : GeoHashUtils.BASE32_CHARS) {
            list.add(geoHash + c);
        }
        return list.toArray(new String[0]);
    }

    public static String[] subHashes(final String geoHash, final int length) {
        final String[] geohashs = subHashes(geoHash);
        if (geoHash.length() > length) {
            return new String[0];
        }
        if (geoHash.length() == length) {
            return new String[]{geoHash};
        }
        if (geohashs.length == 0 || geohashs[0].length() == length) {
            return geohashs;
        }
        final ArrayList<String> list = new ArrayList<String>();
        for (final String geohash : geohashs) {
            for (final String subGeohash : subHashes(geohash, length)) {
                list.add(subGeohash);
            }
        }
        return list.toArray(new String[0]);
    }

    public static String[] subHashesN(final String geoHash) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final char c : GeoHashUtils.BASE32_CHARS) {
            if (c >= '0' && c <= 'g') {
                list.add(geoHash + c);
            }
        }
        return list.toArray(new String[0]);
    }

    public static String[] subHashesS(final String geoHash) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final char c : GeoHashUtils.BASE32_CHARS) {
            if (c >= 'h' && c <= 'z') {
                list.add(geoHash + c);
            }
        }
        return list.toArray(new String[0]);
    }

    public static String[] subHashesNW(final String geoHash) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final char c : GeoHashUtils.BASE32_CHARS) {
            if (c >= '0' && c <= '7') {
                list.add(geoHash + c);
            }
        }
        return list.toArray(new String[0]);
    }

    public static String[] subHashesNE(final String geoHash) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final char c : GeoHashUtils.BASE32_CHARS) {
            if (c >= '8' && c <= 'g') {
                list.add(geoHash + c);
            }
        }
        return list.toArray(new String[0]);
    }

    public static String[] subHashesSW(final String geoHash) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final char c : GeoHashUtils.BASE32_CHARS) {
            if (c >= 'h' && c <= 'r') {
                list.add(geoHash + c);
            }
        }
        return list.toArray(new String[0]);
    }

    public static String[] subHashesSE(final String geoHash) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final char c : GeoHashUtils.BASE32_CHARS) {
            if (c >= 's' && c <= 'z') {
                list.add(geoHash + c);
            }
        }
        return list.toArray(new String[0]);
    }

    public static Set<String> geoHashesForPolygon(final boolean partiallyContainedKeep, final double[]... polygonPoints) {
        final double[] bbox = GeoGeometry.boundingBox(polygonPoints);
        final double diagonal = GeoGeometry.distance(bbox[0], bbox[2], bbox[1], bbox[3]);
        final int hashLength = suitableHashLength(diagonal, bbox[0], bbox[2]);
        return geoHashesForPolygon(hashLength + 1, partiallyContainedKeep, polygonPoints);
    }

    public static Set<String> geoHashesForPolygon(final int maxLength, final boolean partiallyContainedKeep, final double[]... polygonPoints) {
        for (final double[] ds : polygonPoints) {
            if (ds[1] < -89.5 || ds[1] > 89.5) {
                throw new IllegalArgumentException("please stay away from the north pole or the south pole; there are some known issues there. Besides, nothing there but snow and ice.");
            }
        }
        if (maxLength < 1 || maxLength >= GeoHashUtils.DEFAULT_PRECISION) {
            throw new IllegalArgumentException("maxLength should be between 2 and " + GeoHashUtils.DEFAULT_PRECISION + " was " + maxLength);
        }
        final double[] bbox = GeoGeometry.boundingBox(polygonPoints);
        final double diagonal = GeoGeometry.distance(bbox[0], bbox[2], bbox[1], bbox[3]);
        final int hashLength = suitableHashLength(diagonal, bbox[0], bbox[2]);
        Set<String> partiallyContained = new HashSet<String>();
        String rowHash = encode(bbox[0], bbox[2], hashLength);
        for (double[] rowBox = decode_bbox(rowHash); rowBox[0] < bbox[1]; rowBox = decode_bbox(rowHash)) {
            String columnHash = rowHash;
            for (double[] columnBox = rowBox; isWest(columnBox[2], bbox[3]); columnBox = decode_bbox(columnHash)) {
                partiallyContained.add(columnHash);
                columnHash = east(columnHash);
            }
            rowHash = south(rowHash);
        }
        final Set<String> fullyContained = new TreeSet<String>();
        for (int detail = hashLength; detail < maxLength; ++detail) {
            partiallyContained = splitAndFilter(polygonPoints, fullyContained, partiallyContained);
        }
        if (partiallyContainedKeep) {
            fullyContained.addAll(partiallyContained);
        }
        return fullyContained;
    }

    public static boolean isWest(final double l1, final double l2) {
        final double ll1 = l1 + 180.0;
        final double ll2 = l2 + 180.0;
        return (ll1 < ll2 && ll2 - ll1 < 180.0) || (ll1 > ll2 && ll2 + 360.0 - ll1 < 180.0);
    }

    public static boolean isEast(final double l1, final double l2) {
        final double ll1 = l1 + 180.0;
        final double ll2 = l2 + 180.0;
        return (ll1 > ll2 && ll1 - ll2 < 180.0) || (ll1 < ll2 && ll1 + 360.0 - ll2 < 180.0);
    }

    public static boolean isNorth(final double l1, final double l2) {
        return l1 > l2;
    }

    public static boolean isSouth(final double l1, final double l2) {
        return l1 < l2;
    }

    public static boolean bboxContainsNotBorder(final double[] bbox, final double latitude, final double longitude) {
        GeoGeometry.validate(latitude, longitude);
        return bbox[0] < latitude && latitude < bbox[1] && bbox[2] < longitude && longitude < bbox[3];
    }

    public static boolean geohashCross(final String geohash, final double lat1, final double lon1, final double lat2, final double lon2) {
        final double[] hashBbox = decode_bbox(geohash);
        return LineUtils.linesCross(hashBbox[0], hashBbox[2], hashBbox[0], hashBbox[3], lat1, lon1, lat2, lon2) || LineUtils.linesCross(hashBbox[0], hashBbox[3], hashBbox[1], hashBbox[3], lat1, lon1, lat2, lon2) || LineUtils.linesCross(hashBbox[1], hashBbox[3], hashBbox[1], hashBbox[2], lat1, lon1, lat2, lon2) || LineUtils.linesCross(hashBbox[1], hashBbox[2], hashBbox[0], hashBbox[2], lat1, lon1, lat2, lon2);
    }

    private static Set<String> splitAndFilter(final double[][] polygonPoints, final Set<String> fullyContained, final Set<String> partiallyContained) {
        final Set<String> stillPartial = new HashSet<String>();
        for (final String hash : partiallyContained) {
            for (final String h : subHashes(hash)) {
                final double[] hashBbox = decode_bbox(h);
                final boolean nw = GeoGeometry.polygonContains(new double[]{hashBbox[2], hashBbox[0]}, polygonPoints);
                final boolean ne = GeoGeometry.polygonContains(new double[]{hashBbox[3], hashBbox[0]}, polygonPoints);
                final boolean sw = GeoGeometry.polygonContains(new double[]{hashBbox[2], hashBbox[1]}, polygonPoints);
                final boolean se = GeoGeometry.polygonContains(new double[]{hashBbox[3], hashBbox[1]}, polygonPoints);
                boolean hashBboxContainsNotBorder = false;
                for (int i = 0; i < polygonPoints.length; ++i) {
                    if (bboxContainsNotBorder(hashBbox, polygonPoints[i][1], polygonPoints[i][0])) {
                        hashBboxContainsNotBorder = true;
                        break;
                    }
                }
                if (nw && ne && sw && se && !hashBboxContainsNotBorder) {
                    fullyContained.add(h);
                } else if (nw || ne || sw || se || hashBboxContainsNotBorder) {
                    stillPartial.add(h);
                } else {
                    for (int i = 1; i < polygonPoints.length; ++i) {
                        final double[] last = polygonPoints[i - 1];
                        final double[] current = polygonPoints[i];
                        if (GeoGeometry.linesCross(hashBbox[0], hashBbox[2], hashBbox[0], hashBbox[3], last[1], last[0], current[1], current[0])) {
                            stillPartial.add(h);
                            break;
                        }
                        if (GeoGeometry.linesCross(hashBbox[0], hashBbox[3], hashBbox[1], hashBbox[3], last[1], last[0], current[1], current[0])) {
                            stillPartial.add(h);
                            break;
                        }
                        if (GeoGeometry.linesCross(hashBbox[1], hashBbox[3], hashBbox[1], hashBbox[2], last[1], last[0], current[1], current[0])) {
                            stillPartial.add(h);
                            break;
                        }
                        if (GeoGeometry.linesCross(hashBbox[1], hashBbox[2], hashBbox[0], hashBbox[2], last[1], last[0], current[1], current[0])) {
                            stillPartial.add(h);
                            break;
                        }
                    }
                }
            }
        }
        return stillPartial;
    }

    public static Set<String> geoHashesForPath(final int hashLength, final double[]... wayPoints) {
        if (wayPoints == null || wayPoints.length < 2) {
            throw new IllegalArgumentException("must have at least two way points on the path");
        }
        final Set<String> hashes = new TreeSet<String>();
        for (int i = 1; i < wayPoints.length; ++i) {
            final double[] previousPoint = wayPoints[i - 1];
            final double[] point = wayPoints[i];
            hashes.addAll(geoHashesForLine(hashLength, previousPoint[0], previousPoint[1], point[0], point[1]));
        }
        return hashes;
    }

    public static Set<String> geoHashesForLine(final double width, final double lat1, final double lon1, final double lat2, final double lon2) {
        final double diff = 9.999999974752427E-7;
        if (Math.abs(lat1 - lat2) < diff && Math.abs(lon1 - lon2) < diff) {
            return new HashSet<String>();
        }
        final int hashLength = suitableHashLength(width, lat1, lon1);
        final Object[] result1 = encodeWithBbox(lat1, lon1, hashLength);
        final double[] bbox1Tmp = (double[]) result1[1];
        final double[] bbox1 = {bbox1Tmp[2], bbox1Tmp[3], bbox1Tmp[0], bbox1Tmp[1]};
        final Object[] result2 = encodeWithBbox(lat2, lon2, hashLength);
        final double[] bbox2Tmp = (double[]) result2[1];
        final double[] bbox2 = {bbox2Tmp[2], bbox2Tmp[3], bbox2Tmp[0], bbox2Tmp[1]};
        if (result1[0].equals(result2[0])) {
            final Set<String> results = new HashSet<String>();
            results.add((String) result1[0]);
            return results;
        }
        if (Math.abs(lat1 - lat2) >= diff) {
            final Set<String> results = new HashSet<String>();
            final Set<String> tmpResults = geoHashesForPolygon(hashLength, true, new double[][]{{bbox1[0], bbox1[2]}, {bbox1[1], bbox1[2]}, {bbox2[1], bbox2[3]}, {bbox2[0], bbox2[3]}});
            for (final String h : tmpResults) {
                if (geohashCross(h, lat1, lon1, lat2, lon2)) {
                    results.add(h);
                }
            }
            return results;
        }
        final Set<String> results = new HashSet<String>();
        final Set<String> tmpResults = geoHashesForPolygon(hashLength, true, new double[][]{{bbox1[0], bbox1[2]}, {bbox1[0], bbox1[3]}, {bbox2[1], bbox2[2]}, {bbox2[1], bbox2[3]}});
        for (final String h : tmpResults) {
            if (geohashCross(h, lat1, lon1, lat2, lon2)) {
                results.add(h);
            }
        }
        return results;
    }

    private static Object[] encodeWithBbox(double latitude, double longitude, int length) {
        if (length < 1 || length > 12) {
            throw new IllegalArgumentException("length must be between 1 and 12");
        }
         double[] latInterval = {-90.0, 90.0};
         double[] lonInterval = {-180.0, 180.0};
         StringBuilder geohash = new StringBuilder();
        boolean is_even = true;
        int bit = 0;
        int ch = 0;
        while (geohash.length() < length) {
            double mid = 0.0;
            if (is_even) {
                mid = (lonInterval[0] + lonInterval[1]) / 2.0;
                if (longitude > mid) {
                    ch |= GeoHashUtils.BITS[bit];
                    lonInterval[0] = mid;
                } else {
                    lonInterval[1] = mid;
                }
            } else {
                mid = (latInterval[0] + latInterval[1]) / 2.0;
                if (latitude > mid) {
                    ch |= GeoHashUtils.BITS[bit];
                    latInterval[0] = mid;
                } else {
                    latInterval[1] = mid;
                }
            }
            is_even = !is_even;
            if (bit < 4) {
                ++bit;
            } else {
                geohash.append(GeoHashUtils.BASE32_CHARS[ch]);
                bit = 0;
                ch = 0;
            }
        }
        return new Object[]{geohash.toString(), new Double[]{latInterval[0], latInterval[1], lonInterval[0], lonInterval[1]}};
    }

    public static Set<String> geoHashesForCircle(int length, double latitude, double longitude, double radius) {
        final int suitableHashLength = suitableHashLength(radius, latitude, longitude);
        int segments;
        if (length > suitableHashLength - 3) {
            segments = 200;
        } else if (length > suitableHashLength - 2) {
            segments = 100;
        } else if (length > suitableHashLength - 1) {
            segments = 50;
        } else {
            segments = 15;
        }
        final double[][] circle2polygon = GeoGeometry.circle2polygon(segments, latitude, longitude, radius);
        return geoHashesForPolygon(length, false, circle2polygon);
    }

    public static int suitableHashLength(final double granularityInMeters, final double latitude, final double longitude) {
        if (granularityInMeters < 5.0) {
            return 10;
        }
        String hash = encode(latitude, longitude);
        double width = 0.0;
        int length = hash.length();
        while (width < granularityInMeters && hash.length() >= 2) {
            length = hash.length();
            final double[] bbox = decode_bbox(hash);
            width = GeoGeometry.distance(bbox[0], bbox[2], bbox[0], bbox[3]);
            hash = hash.substring(0, hash.length() - 1);
        }
        return Math.min(length + 1, GeoHashUtils.DEFAULT_PRECISION);
    }

    static {
        GeoHashUtils.DEFAULT_PRECISION = 12;
        GeoHashUtils.BITS = new int[]{16, 8, 4, 2, 1};
        GeoHashUtils.BASE32_CHARS = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        BASE32_DECODE_MAP = new HashMap<Character, Integer>();
        for (int i = 0; i < GeoHashUtils.BASE32_CHARS.length; ++i) {
            GeoHashUtils.BASE32_DECODE_MAP.put(GeoHashUtils.BASE32_CHARS[i], i);
        }
        GEOHASH_ENDINGS = new char[][]{{'0', '2', '8', 'b'}, {'1', '3', '9', 'c'}, {'4', '6', 'd', 'f'}, {'5', '7', 'e', 'g'}, {'h', 'k', 's', 'u'}, {'j', 'm', 't', 'v'}, {'n', 'q', 'w', 'y'}, {'p', 'r', 'x', 'z'}};
    }
}
