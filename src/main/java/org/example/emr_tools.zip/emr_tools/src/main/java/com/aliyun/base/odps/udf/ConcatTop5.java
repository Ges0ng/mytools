package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;

import java.util.*;

public class ConcatTop5 extends UDF {
    public String evaluate(String str){
        if(str==null){
            return null;
        }
        Map<String,Integer> map=new HashMap<String,Integer>();
        String[] strs=str.split(";");
        for (String index:strs){
            if(map.containsKey(index.split(",")[0])){
                map.put(index.split(",")[0],map.get(index.split(",")[0])+Integer.valueOf(index.split(",")[1]));
            }else {
                map.put(index.split(",")[0],Integer.valueOf(index.split(",")[1]));
            }
        }
        List<String> list=new ArrayList<>();
        Set set=map.entrySet();
        Map.Entry[] entrys=(Map.Entry[])set.toArray(new Map.Entry[set.size()]);
        for(Map.Entry entry:entrys){
            list.add(entry.getKey()+","+entry.getValue());
        }
        list.sort(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return Integer.valueOf(o2.split(",")[1])-Integer.valueOf(o1.split(",")[1]);
            }
        });
        if(list.size()>5){
            list=list.subList(0,5);
        }
        return StringUtils.join(list,";");
    }

    public static void main(String[] args) {
        System.out.println(new ConcatTop5().evaluate("1,1;3,3;4,4;2,1;哈哈,8"));
    }
}
