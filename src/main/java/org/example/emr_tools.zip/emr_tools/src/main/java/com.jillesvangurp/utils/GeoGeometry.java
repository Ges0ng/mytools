package com.jillesvangurp.utils;

import java.util.*;
import org.apache.commons.lang.*;

public class GeoGeometry
{
    private static final double EARTH_RADIUS = 6371000.0;
    private static final double EARTH_RADIUS_METERS = 6371000.0;
    private static final double EARTH_CIRCUMFERENCE_METERS = 4.003017359204114E7;
    private static final double DEGREE_LATITUDE_METERS = 111194.92664455873;

    public static double[] boundingBox(final double[] point) {
        return new double[] { point[1], point[1], point[0], point[0] };
    }

    public static double[] boundingBox(final double[][] lineString) {
        double minLat = 2.147483647E9;
        double minLon = 2.147483647E9;
        double maxLat = -2.147483648E9;
        double maxLon = -2.147483648E9;
        for (int i = 0; i < lineString.length; ++i) {
            minLat = Math.min(minLat, lineString[i][1]);
            minLon = Math.min(minLon, lineString[i][0]);
            maxLat = Math.max(maxLat, lineString[i][1]);
            maxLon = Math.max(maxLon, lineString[i][0]);
        }
        return new double[] { minLat, maxLat, minLon, maxLon };
    }

    public static double[] boundingBox(final double[][][] polygon) {
        double minLat = 2.147483647E9;
        double minLon = 2.147483647E9;
        double maxLat = -2.147483648E9;
        double maxLon = -2.147483648E9;
        for (int i = 0; i < polygon.length; ++i) {
            for (int j = 0; j < polygon[i].length; ++j) {
                minLat = Math.min(minLat, polygon[i][j][1]);
                minLon = Math.min(minLon, polygon[i][j][0]);
                maxLat = Math.max(maxLat, polygon[i][j][1]);
                maxLon = Math.max(maxLon, polygon[i][j][0]);
            }
        }
        return new double[] { minLat, maxLat, minLon, maxLon };
    }

    public static double[] boundingBox(final double[][][][] multiPolygon) {
        double minLat = 2.147483647E9;
        double minLon = 2.147483647E9;
        double maxLat = -2.147483648E9;
        double maxLon = -2.147483648E9;
        for (int i = 0; i < multiPolygon.length; ++i) {
            for (int j = 0; j < multiPolygon[i].length; ++j) {
                for (int k = 0; k < multiPolygon[i][j].length; ++k) {
                    minLat = Math.min(minLat, multiPolygon[i][j][k][1]);
                    minLon = Math.min(minLon, multiPolygon[i][j][k][0]);
                    maxLat = Math.max(maxLat, multiPolygon[i][j][k][1]);
                    maxLon = Math.max(maxLon, multiPolygon[i][j][k][0]);
                }
            }
        }
        return new double[] { minLat, maxLat, minLon, maxLon };
    }

    public static double[][] filterNoiseFromPointCloud(final double[][] points, final float percentage) {
        Arrays.sort(points, new Comparator() {
            @Override
            public int compare(final Object o1, final Object o2) {
                final double[] p1 = (double[])o1;
                final double[] p2 = (double[])o2;
                if (p1[0] == p2[0]) {
                    if (p1[1] > p2[1]) {
                        return 1;
                    }
                    if (p1[1] == p2[1]) {
                        return 0;
                    }
                    return -1;
                }
                else {
                    if (p1[0] > p2[0]) {
                        return 1;
                    }
                    if (p1[0] == p2[0]) {
                        return 0;
                    }
                    return -1;
                }
            }
        });
        final int discard = (int)(points.length * percentage / 2.0f);
        return Arrays.copyOfRange(points, discard, points.length - discard);
    }

    public static boolean bboxContains(final double[] bbox, final double latitude, final double longitude) {
        validate(latitude, longitude);
        return bbox[0] <= latitude && latitude <= bbox[1] && bbox[2] <= longitude && longitude <= bbox[3];
    }

    public static boolean polygonContains(final double[] point, final double[][][] polygonPoints) {
        validate(point);
        return polygonContains(point[1], point[0], polygonPoints[0]);
    }

    public static boolean polygonContains(final double[] point, final double[]... polygonPoints) {
        validate(point);
        return polygonContains(point[1], point[0], polygonPoints);
    }

    public static boolean polygonContains(final double latitude, final double longitude, final double[][][] polygonPoints) {
        validate(latitude, longitude);
        return polygonContains(latitude, longitude, polygonPoints[0]);
    }

    public static boolean polygonContains(final double latitude, final double longitude, final double[]... polygonPoints) {
        validate(latitude, longitude);
        if (polygonPoints.length <= 2) {
            throw new IllegalArgumentException("a polygon must have at least three points");
        }
        final double[] bbox = boundingBox(polygonPoints);
        if (!bboxContains(bbox, latitude, longitude)) {
            return false;
        }
        int hits = 0;
        double lastLatitude = polygonPoints[polygonPoints.length - 1][1];
        double lastLongitude = polygonPoints[polygonPoints.length - 1][0];
        for (int i = 0; i < polygonPoints.length; ++i) {
            final double currentLatitude = polygonPoints[i][1];
            final double currentLongitude = polygonPoints[i][0];
            Label_0265: {
                if (currentLongitude != lastLongitude) {
                    double leftLatitude;
                    if (currentLatitude < lastLatitude) {
                        if (latitude >= lastLatitude) {
                            break Label_0265;
                        }
                        leftLatitude = currentLatitude;
                    }
                    else {
                        if (latitude >= currentLatitude) {
                            break Label_0265;
                        }
                        leftLatitude = lastLatitude;
                    }
                    double test1;
                    double test2;
                    if (currentLongitude < lastLongitude) {
                        if (longitude < currentLongitude) {
                            break Label_0265;
                        }
                        if (longitude >= lastLongitude) {
                            break Label_0265;
                        }
                        if (latitude < leftLatitude) {
                            ++hits;
                            break Label_0265;
                        }
                        test1 = latitude - currentLatitude;
                        test2 = longitude - currentLongitude;
                    }
                    else {
                        if (longitude < lastLongitude) {
                            break Label_0265;
                        }
                        if (longitude >= currentLongitude) {
                            break Label_0265;
                        }
                        if (latitude < leftLatitude) {
                            ++hits;
                            break Label_0265;
                        }
                        test1 = latitude - lastLatitude;
                        test2 = longitude - lastLongitude;
                    }
                    if (test1 < test2 / (lastLongitude - currentLongitude) * (lastLatitude - currentLatitude)) {
                        ++hits;
                    }
                }
            }
            lastLatitude = currentLatitude;
            lastLongitude = currentLongitude;
        }
        return (hits & 0x1) != 0x0;
    }

    public static double roundToDecimals(final double d, final int decimals) {
        if (decimals > 17) {
            throw new IllegalArgumentException("this probably doesn't do what you want; makes sense only for <= 17 decimals");
        }
        final double factor = Math.pow(10.0, decimals);
        return Math.round(d * factor) / factor;
    }

    public static boolean linesCross(final double x1, final double y1, final double x2, final double y2, final double u1, final double v1, final double u2, final double v2) {
        final boolean line1Vertical = x2 == x1;
        final boolean line2Vertical = u2 == u1;
        if (line1Vertical && line2Vertical) {
            return x1 == u1 && ((y1 <= v1 && v1 < y2) || (y1 <= v2 && v2 < y2));
        }
        if (line1Vertical && !line2Vertical) {
            final double b2 = (v2 - v1) / (u2 - u1);
            final double a2 = v1 - b2 * u1;
            final double xi = x1;
            final double yi = a2 + b2 * xi;
            return yi >= y1 && yi <= y2;
        }
        if (!line1Vertical && line2Vertical) {
            final double b3 = (y2 - y1) / (x2 - x1);
            final double a3 = y1 - b3 * x1;
            final double xi = u1;
            final double yi = a3 + b3 * xi;
            return yi >= v1 && yi <= v2;
        }
        final double b3 = (y2 - y1) / (x2 - x1);
        final double b4 = (v2 - v1) / (u2 - u1);
        final double a4 = y1 - b3 * x1;
        final double a5 = v1 - b4 * u1;
        if (b3 - b4 == 0.0) {
            return Math.abs(a4 - a5) < 1.0E-7 && ((x1 <= u1 && u1 < x2) || (x1 <= u2 && u2 < x2));
        }
        final double xi2 = -(a4 - a5) / (b3 - b4);
        final double yi2 = a4 + b3 * xi2;
        return (x1 - xi2) * (xi2 - x2) >= 0.0 && (u1 - xi2) * (xi2 - u2) >= 0.0 && (y1 - yi2) * (yi2 - y2) >= 0.0 && (v1 - yi2) * (yi2 - v2) >= 0.0;
    }

    private static double lengthOfLongitudeDegreeAtLatitude(final double latitude) {
        final double latitudeInRadians = Math.toRadians(latitude);
        return Math.cos(latitudeInRadians) * 4.003017359204114E7 / 360.0;
    }

    public static double[] translateLongitude(final double latitude, final double longitude, final double meters) {
        validate(latitude, longitude);
        return new double[] { roundToDecimals(longitude + meters / lengthOfLongitudeDegreeAtLatitude(latitude), 6), latitude };
    }

    public static double[] translateLatitude(final double latitude, final double longitude, final double meters) {
        return new double[] { longitude, roundToDecimals(latitude + meters / 111194.92664455873, 6) };
    }

    public static double[] translate(final double latitude, final double longitude, final double lateralMeters, final double longitudalMeters) {
        validate(latitude, longitude);
        final double[] longitudal = translateLongitude(latitude, longitude, longitudalMeters);
        return translateLatitude(longitudal[1], longitudal[0], lateralMeters);
    }

    public static double[] bbox(final double latitude, final double longitude, final double latitudalMeters, final double longitudalMeters) {
        validate(latitude, longitude);
        final double[] tr = translate(latitude, longitude, latitudalMeters / 2.0, longitudalMeters / 2.0);
        final double[] br = translate(latitude, longitude, -latitudalMeters / 2.0, longitudalMeters / 2.0);
        final double[] bl = translate(latitude, longitude, -latitudalMeters / 2.0, -longitudalMeters / 2.0);
        return new double[] { tr[1], br[1], tr[0], bl[0] };
    }

    public static double distance(final double lat1, final double long1, final double lat2, final double long2) {
        validate(lat1, long1);
        validate(lat2, long2);
        final double deltaLat = Math.toRadians(lat2 - lat1);
        final double deltaLon = Math.toRadians(long2 - long1);
        final double a = Math.sin(deltaLat / 2.0) * Math.sin(deltaLat / 2.0) + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(deltaLon / 2.0) * Math.sin(deltaLon / 2.0);
        final double c = 2.0 * Math.asin(Math.sqrt(a));
        return 6371000.0 * c;
    }

    public static double distance(final double[] firstCoordinate, final double[] secondCoordinate) {
        return distance(firstCoordinate[1], firstCoordinate[0], secondCoordinate[1], secondCoordinate[0]);
    }

    public static double distance(final double x1, final double y1, final double x2, final double y2, final double x, final double y) {
        validate(x1, y1);
        validate(x2, y2);
        validate(x, y);
        double xx;
        double yy;
        if (y1 == y2) {
            xx = x;
            yy = y1;
        }
        else if (x1 == x2) {
            xx = x1;
            yy = y;
        }
        else {
            final double s = (y2 - y1) / (x2 - x1);
            final double c = y1 - s * x1;
            final double ps = -1.0 / s;
            final double pc = y - ps * x;
            xx = (c - pc) / (ps - s);
            yy = s * xx + c;
        }
        if (onSegment(xx, yy, x1, y1, x2, y2)) {
            return distance(x, y, xx, yy);
        }
        return Math.min(distance(x, y, x1, y1), distance(x, y, x2, y2));
    }

    private static boolean onSegment(final double x, final double y, final double x1, final double y1, final double x2, final double y2) {
        final double minx = Math.min(x1, x2);
        final double maxx = Math.max(x1, x2);
        final double miny = Math.min(y1, y2);
        final double maxy = Math.max(y1, y2);
        final boolean result = x >= minx && x <= maxx && y >= miny && y <= maxy;
        return result;
    }

    public static double distance(final double[] l1, final double[] l2, final double[] p) {
        return distance(l1[1], l1[0], l2[1], l2[0], p[1], p[0]);
    }

    public static double distanceToLineString(final double[] point, final double[][] lineString) {
        if (lineString.length < 2) {
            throw new IllegalArgumentException("not enough segments in line");
        }
        double minDistance = Double.MAX_VALUE;
        double[] last = lineString[0];
        for (int i = 1; i < lineString.length; ++i) {
            final double[] current = lineString[i];
            final double distance = distance(last, current, point);
            minDistance = Math.min(minDistance, distance);
            last = current;
        }
        return minDistance;
    }

    public static double distanceToPolygon(final double[] point, final double[][] polygon) {
        if (polygon.length < 3) {
            throw new IllegalArgumentException("not enough segments in polygon");
        }
        if (polygonContains(point, polygon)) {
            return 0.0;
        }
        return distanceToLineString(point, polygon);
    }

    public static double distanceToPolygon(final double[] point, final double[][][] polygon) {
        if (polygon.length == 0) {
            throw new IllegalArgumentException("empty polygon");
        }
        return distanceToPolygon(point, polygon[0]);
    }

    public static double distanceToMultiPolygon(final double[] point, final double[][][][] multiPolygon) {
        double distance = Double.MAX_VALUE;
        for (final double[][][] polygon : multiPolygon) {
            distance = Math.min(distance, distanceToPolygon(point, polygon));
        }
        return distance;
    }

    public static double[] polygonCenter(final double[]... polygonPoints) {
        double cumLon = 0.0;
        double cumLat = 0.0;
        for (final double[] coordinate : polygonPoints) {
            cumLon += coordinate[0];
            cumLat += coordinate[1];
        }
        return new double[] { cumLon / polygonPoints.length, cumLat / polygonPoints.length };
    }

    public static double[][] bbox2polygon(final double[] bbox) {
        return new double[][] { { bbox[2], bbox[0] }, { bbox[2], bbox[1] }, { bbox[3], bbox[1] }, { bbox[3], bbox[0] }, { bbox[2], bbox[0] } };
    }

    public static double[][] circle2polygon(final int segments, final double latitude, final double longitude, final double radius) {
        validate(latitude, longitude);
        if (segments < 5) {
            throw new IllegalArgumentException("you need a minimum of 5 segments");
        }
        final double[][] points = new double[segments + 1][0];
        final double relativeLatitude = radius / 6371000.0 * 180.0 / 3.141592653589793;
        final double relativeLongitude = relativeLatitude / Math.cos(Math.toRadians(latitude)) % 90.0;
        for (int i = 0; i < segments; ++i) {
            double theta = 6.283185307179586 * i / segments;
            theta = (theta += 0.1);
            if (theta >= 6.283185307179586) {
                theta -= 6.283185307179586;
            }
            double latOnCircle = latitude + relativeLatitude * Math.sin(theta);
            double lonOnCircle = longitude + relativeLongitude * Math.cos(theta);
            if (lonOnCircle > 180.0) {
                lonOnCircle = -180.0 + (lonOnCircle - 180.0);
            }
            else if (lonOnCircle < -180.0) {
                lonOnCircle = 180.0 - (lonOnCircle + 180.0);
            }
            if (latOnCircle > 90.0) {
                latOnCircle = 90.0 - (latOnCircle - 90.0);
            }
            else if (latOnCircle < -90.0) {
                latOnCircle = -90.0 - (latOnCircle + 90.0);
            }
            points[i] = new double[] { lonOnCircle, latOnCircle };
        }
        points[points.length - 1] = new double[] { points[0][0], points[0][1] };
        return points;
    }

    public static boolean overlap(final double[][] left, final double[][] right) {
        if (polygonContains(polygonCenter(right), left)) {
            return true;
        }
        if (polygonContains(polygonCenter(left), right)) {
            return true;
        }
        for (final double[] p : right) {
            if (polygonContains(p, left)) {
                return true;
            }
        }
        for (final double[] p : left) {
            if (polygonContains(p, right)) {
                return true;
            }
        }
        return false;
    }

    public static boolean contains(final double[][] containingPolygon, final double[][] containedPolygon) {
        for (final double[] p : containedPolygon) {
            if (!polygonContains(p, containingPolygon)) {
                return false;
            }
        }
        return true;
    }

    public static double[][] expandPolygon(final int meters, final double[][] points) {
        final double[][] expanded = new double[points.length * 8][0];
        for (int i = 0; i < points.length; ++i) {
            final double[] p = points[i];
            final double lonPos = translateLongitude(p[0], p[1], meters)[0];
            final double lonNeg = translateLongitude(p[0], p[1], -1 * meters)[0];
            final double latPos = translateLatitude(p[0], p[1], meters)[1];
            final double latNeg = translateLatitude(p[0], p[1], -1 * meters)[1];
            expanded[i * 8] = new double[] { lonPos, latPos };
            expanded[i * 8 + 1] = new double[] { lonPos, latNeg };
            expanded[i * 8 + 2] = new double[] { lonNeg, latPos };
            expanded[i * 8 + 3] = new double[] { lonNeg, latNeg };
            expanded[i * 8 + 4] = new double[] { lonPos, p[1] };
            expanded[i * 8 + 5] = new double[] { lonNeg, p[1] };
            expanded[i * 8 + 6] = new double[] { p[0], latPos };
            expanded[i * 8 + 7] = new double[] { p[1], latNeg };
        }
        return polygonForPoints(expanded);
    }

    public static double[][] polygonForPoints(final double[][] points) {
        if (points.length < 3) {
            throw new IllegalStateException("need at least 3 pois for a polygon");
        }
        final double[][] sorted = Arrays.copyOf(points, points.length);
        Arrays.sort(sorted, new Comparator() {
            @Override
            public int compare(final Object o1, final Object o2) {
                final double[] p1 = (double[])o1;
                final double[] p2 = (double[])o2;
                if (p1[0] == p2[0]) {
                    return new Double(p1[1]).compareTo(new Double(p2[1]));
                }
                return new Double(p1[0]).compareTo(new Double(p2[0]));
            }
        });
        final int n = sorted.length;
        final double[][] lUpper = new double[n][0];
        lUpper[0] = sorted[0];
        lUpper[1] = sorted[1];
        int lUpperSize = 2;
        for (int i = 2; i < n; ++i) {
            lUpper[lUpperSize] = sorted[i];
            ++lUpperSize;
            while (lUpperSize > 2 && !rightTurn(lUpper[lUpperSize - 3], lUpper[lUpperSize - 2], lUpper[lUpperSize - 1])) {
                lUpper[lUpperSize - 2] = lUpper[lUpperSize - 1];
                --lUpperSize;
            }
        }
        final double[][] lLower = new double[n][0];
        lLower[0] = sorted[n - 1];
        lLower[1] = sorted[n - 2];
        int lLowerSize = 2;
        for (int j = n - 3; j >= 0; --j) {
            lLower[lLowerSize] = sorted[j];
            ++lLowerSize;
            while (lLowerSize > 2 && !rightTurn(lLower[lLowerSize - 3], lLower[lLowerSize - 2], lLower[lLowerSize - 1])) {
                lLower[lLowerSize - 2] = lLower[lLowerSize - 1];
                --lLowerSize;
            }
        }
        final double[][] result = new double[lUpperSize + lLowerSize - 1][0];
        int idx = 0;
        for (int k = 0; k < lUpperSize; ++k) {
            result[idx] = lUpper[k];
            ++idx;
        }
        for (int k = 1; k < lLowerSize - 1; ++k) {
            result[idx] = lLower[k];
            ++idx;
        }
        result[result.length - 1] = result[0];
        return result;
    }

    static boolean rightTurn(final double[] a, final double[] b, final double[] c) {
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]) > 0.0;
    }

    public static double toDecimalDegree(final String direction, final double degrees, final double minutes, final double seconds) {
        int factor = 1;
        if (direction != null && (direction.toLowerCase().startsWith("w") || direction.toLowerCase().startsWith("s"))) {
            factor = -1;
        }
        return (degrees + minutes / 60.0 + seconds / 60.0 / 60.0) * factor;
    }

    public static String toJson(final double[] point) {
        if (point.length == 0) {
            return "[]";
        }
        return "[" + point[0] + ',' + point[1] + "]";
    }

    public static String toJson(final double[][] points) {
        final StringBuilder buf = new StringBuilder("[");
        for (int i = 0; i < points.length; ++i) {
            buf.append(toJson(points[i]));
            if (i < points.length - 1) {
                buf.append(',');
            }
        }
        buf.append("]");
        return buf.toString();
    }

    public static String toJson(final double[][][] points) {
        final StringBuilder buf = new StringBuilder("[");
        for (int i = 0; i < points.length; ++i) {
            buf.append(toJson(points[i]));
            if (i < points.length - 1) {
                buf.append(',');
            }
        }
        buf.append("]");
        return buf.toString();
    }

    public static String toJson(final double[][][][] points) {
        final StringBuilder buf = new StringBuilder("[");
        for (int i = 0; i < points.length; ++i) {
            buf.append(toJson(points[i]));
            if (i < points.length - 1) {
                buf.append(',');
            }
        }
        buf.append("]");
        return buf.toString();
    }

    public static void validate(final double latitude, final double longitude) {
        final double roundedLat = Math.round(latitude * 1000000.0) / 1000000.0;
        final double roundedLon = Math.round(longitude * 1000000.0) / 1000000.0;
        if (roundedLat < -90.0 || roundedLat > 90.0) {
            throw new IllegalArgumentException("Latitude " + latitude + " is outside legal range of -90,90");
        }
        if (roundedLon < -180.0 || roundedLon > 180.0) {
            throw new IllegalArgumentException("Longitude " + longitude + " is outside legal range of -180,180");
        }
    }

    public static void validate(final double[] point) {
        validate(point[1], point[0]);
    }

    public static double area(final double[][] polygon) {
        Validate.isTrue(polygon.length > 3, "polygon should have at least three elements");
        double total = 0.0;
        double[] previous = polygon[0];
        final double[] center = polygonCenter(polygon);
        final double xRef = center[0];
        final double yRef = center[1];
        for (int i = 1; i < polygon.length; ++i) {
            final double[] current = polygon[i];
            final double x1 = (previous[0] - xRef) * 111319.49079327358 * Math.cos(yRef * 3.141592653589793 / 180.0);
            final double y1 = (previous[1] - yRef) * Math.toRadians(6378137.0);
            final double x2 = (current[0] - xRef) * 111319.49079327358 * Math.cos(yRef * 3.141592653589793 / 180.0);
            final double y2 = (current[1] - yRef) * Math.toRadians(6378137.0);
            total += x1 * y2 - x2 * y1;
            previous = current;
        }
        return 0.5 * Math.abs(total);
    }

    public static double area(final double[] bbox) {
        if (bbox.length != 4) {
            throw new IllegalArgumentException("Boundingbox should be array of [minLat, maxLat, minLon, maxLon]");
        }
        final double latDist = distance(bbox[0], bbox[2], bbox[1], bbox[2]);
        final double lonDist = distance(bbox[0], bbox[2], bbox[0], bbox[3]);
        return latDist * lonDist;
    }

    public static double area(final double[][][] polygon) {
        Validate.isTrue(polygon.length > 0, "should have at least outer polygon");
        double area = area(polygon[0]);
        for (int i = 1; i < polygon.length; ++i) {
            area -= area(polygon[i]);
        }
        return area;
    }

    public static double area(final double[][][][] multiPolygon) {
        double area = 0.0;
        for (int i = 0; i < multiPolygon.length; ++i) {
            area += area(multiPolygon[i]);
        }
        return area;
    }

    public static String pointToString(final double[] p) {
        return "(" + p[0] + "," + p[1] + ")";
    }

    public static String lineToString(final double[][] line) {
        final StringBuilder buf = new StringBuilder();
        for (final double[] p : line) {
            buf.append(pointToString(p) + ",");
        }
        buf.setLength(buf.length() - 1);
        return buf.toString();
    }

    public static double[][][][] simplifyMultiPolygon(final double[][][][] points, final double tolerance) {
        final double[][][][] result = new double[points.length][0][0][0];
        int i = 0;
        for (final double[][][] polygon : points) {
            result[i++] = simplifyPolygon(polygon, tolerance);
        }
        return result;
    }

    public static double[][][] simplifyPolygon(final double[][][] points, final double tolerance) {
        final double[][][] result = new double[points.length][0][0];
        int i = 0;
        for (final double[][] line : points) {
            result[i++] = simplifyLine(line, tolerance);
        }
        return result;
    }

    public static double[][] simplifyLine(final double[][] points, final double tolerance) {
        double dmax = 0.0;
        int index = 0;
        if (points.length == 3) {
            dmax = distance(points[0], points[points.length - 1], points[1]);
        }
        for (int i = 2; i < points.length - 1; ++i) {
            final double d = distance(points[0], points[points.length - 1], points[i]);
            if (d > dmax) {
                index = i;
                dmax = d;
            }
        }
        if (dmax > tolerance && points.length > 3) {
            final double[][] leftArray = new double[index][0];
            System.arraycopy(points, 0, leftArray, 0, index);
            final double[][] left = simplifyLine(leftArray, tolerance);
            final double[][] rightArray = new double[points.length - index][0];
            System.arraycopy(points, index, rightArray, 0, points.length - index);
            final double[][] right = simplifyLine(rightArray, tolerance);
            final double[][] result = new double[left.length + right.length][0];
            System.arraycopy(left, 0, result, 0, left.length);
            System.arraycopy(right, 0, result, left.length, right.length);
            return result;
        }
        if (dmax > tolerance && points.length <= 3) {
            return points;
        }
        final double[][] simplified = { points[0], points[points.length - 1] };
        if (points.length > 2) {
            return simplified;
        }
        return points;
    }
}
