package com.jillesvangurp.utils;

import com.jillesvangurp.geo.GeoGeometry;

public class LineUtils {
    static class Point {
        double x, y;

        public Point(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }

    static class Line {
        Point point1, point2;

        public Line(Point point1, Point point2) {
            this.point1 = point1;
            this.point2 = point2;
        }
    }

    // 快速排斥
    private static boolean rejection(Point a, Point b, Point c, Point d) {
        double minX1 = Math.min(a.x, b.x);
        double maxX1 = Math.max(a.x, b.x);
        double minY1 = Math.min(a.y, b.y);
        double maxY1 = Math.max(a.y, b.y);
        
        double minX2 = Math.min(c.x, d.x);
        double maxX2 = Math.max(c.x, d.x);
        double minY2 = Math.min(c.y, d.y);
        double maxY2 = Math.max(c.y, d.y);

        if (maxX1 >= minX2 && maxX2 >= minX1 && maxY1 >= minY2 && maxY2 >= minY1) {
            return true;
        }
        return false;
    }

    // 行列式计算 ab x ac
    private static double corssProduct(Point a, Point b, Point c) {
        double abx = b.x - a.x;
        double aby = b.y - a.y;
        double acx = c.x - a.x;
        double acy = c.y - a.y;
        return abx * acy - acx * aby;
    }

    // 判断 line1 与 line2 是否相交
    private static boolean linesCross(Line line1, Line line2) {
        Point p1 = line1.point1, p2 = line1.point2;
        Point q1 = line2.point1, q2 = line2.point2;
        // 快速排斥
        if (!rejection(p1, p2, q1, q2)) {
            return false;
        }

        // 跨立实验
        double crossp1 = corssProduct(p1, p2, q1);
        double crossp2 = corssProduct(p1, p2, q2);
        double crossp3 = corssProduct(q1, q2, p1);
        double crossp4 = corssProduct(q1, q2, p2);
        if (crossp1 * crossp2 <= 0 && crossp3 * crossp4 <= 0) {
            return true;
        }
        return false;
    }

    public static boolean linesCross(double x1, double y1, double x2, double y2, double u1, double v1, double u2, double v2) {
        Point point11 = new Point(x1, y1);
        Point point12 = new Point(x2, y2);
        Point point21 = new Point(u1, v1);
        Point point22 = new Point(u2, v2);
        boolean isIntersect = linesCross(new Line(point11, point12), new Line(point21, point22));
        return isIntersect;
    }

    public static void main(String[] args) {
        System.out.println(LineUtils.linesCross(30.50607549756194, 103.9442253112793, 30.593444624569656, 103.9807891845703, 30.611472129821777, 103.98829936981201, 30.611472129821777, 103.98834228515625));
        System.out.println(GeoGeometry.linesCross(30.50607549756194, 103.9442253112793, 30.593444624569656, 103.9807891845703, 30.611472129821777, 103.98829936981201, 30.611472129821777, 103.98834228515625));
    }
}
