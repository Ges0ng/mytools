package com.aliyun.base.odps.udf;
import com.aliyun.odps.udf.UDF;
import com.aliyun.publictransport.odps.udf.SphereDistance;

/**
 * 判断经纬度串线路长度
 */
public class LineLength extends UDF {
    public Double evaluate(String series) {
        String[] split = series.split(";");
        Double length = 0d;
        String[] start1 = split[0].split(",");
        String first = start1[0] + "," + start1[1];
        for (int i = 1; i < split.length; i++) {
            String[] start = first.split(",");
            String[] end = split[i].split(",");
            Double distance = new SphereDistance().evaluate(Double.parseDouble(start[0]), Double.parseDouble(start[1])
                    , Double.parseDouble(end[0]), Double.parseDouble(end[1]));
            if (distance > 50){
                first = split[i];
                length = (length + distance);
            }
        }
        return length;
    }
}