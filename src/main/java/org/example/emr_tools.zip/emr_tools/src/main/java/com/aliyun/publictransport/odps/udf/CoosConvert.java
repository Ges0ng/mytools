package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.*;
import com.jillesvangurp.utils.CoordinateTransformUtil;

public class CoosConvert extends UDF
{
    public String evaluate(final Double lng, final Double lat, final Long type) {
        if (type == 1L) {
            return CoordinateTransformUtil.doubleArrayToStr(CoordinateTransformUtil.wgs84togcj02(lng, lat));
        }
        if (type == 2L) {
            return CoordinateTransformUtil.doubleArrayToStr(CoordinateTransformUtil.gcj02towgs84(lng, lat));
        }
        return CoordinateTransformUtil.doubleArrayToStr(CoordinateTransformUtil.wgs84togcj02(lng, lat));
    }
    
    public String evaluate(final String lng, final String lat, final String type) {
        final Double dlng = Double.valueOf(lng);
        final Double dlat = Double.valueOf(lat);
        final Long ltype = Long.valueOf(type);
        return this.evaluate(dlng, dlat, ltype);
    }
}