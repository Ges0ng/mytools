package com.aliyun.publictransport.odps.udf;

import com.aliyun.base.odps.udf.TimeToIndex;
import com.aliyun.odps.udf.UDF;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class RepeatLength extends UDF {
    /**
     * 计算公交线路重复长度
     * @param station
     * @param lineLength
     * @param station_cnt
     * @return
     */
    public Double evaluate(String station,String lineLength,String station_cnt){
        String[] stations=station.split(",");
        if (stations.length==1||lineLength==null){
            return null;
        }
        List<String> list= Arrays.asList(stations);
        Collections.sort(list, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return Integer.valueOf(o1)-Integer.valueOf(o2);
            }
        });
        int cnt=0;
        for (int i = 1; i < list.size(); i++) {
            if (Integer.valueOf(list.get(i)) - Integer.valueOf(list.get(i - 1)) <= 4) {
                cnt = cnt + Integer.valueOf(list.get(i)) - Integer.valueOf(list.get(i - 1));
            }
        }
        if (cnt==0){
            return null;
        }
        return (double)(Math.round((cnt*Double.valueOf(lineLength)/(Double.valueOf(station_cnt)-1))*1000)/1000.0);

    }

    public static void main(String[] args) {
        System.out.println(new RepeatLength().evaluate("1,5","5.1647","5"));
//        System.out.println(new TimeToIndex().evaluate("35"));
    }
}

