package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;

/**
 * 删除字符串前面的所有0
 */
public class TrimZero extends UDF {
    public String evaluate(String str){
        if(str==null){
            return null;
        }
        str=str.replace("\"","").replaceAll("^(0+)", "");

        return str;
    }

    public static void main(String[] args) {
        System.out.println(new TrimZero().evaluate("00012030"));
    }
}
