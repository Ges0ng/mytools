package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;

public class Point2lineDistance extends UDF {
    public static SphereDistance sphereDistance=new SphereDistance();

    /**
     * 判断点到线段最短距离
     * @param lng1
     * @param lat1
     * @param lng2
     * @param lat2
     * @param lng3
     * @param lat3
     * @return
     */
    public Double evaluate(Double lng1, Double lat1,Double lng2, Double lat2,Double lng3, Double lat3){
        double a=Double.valueOf(sphereDistance.evaluate(lng2,lat2,lng3,lat3));//线段长度
        //点到两段点距离
        double b=Double.valueOf(sphereDistance.evaluate(lng1,lat1,lng3,lat3));
        double c=Double.valueOf(sphereDistance.evaluate(lng1,lat1,lng2,lat2));
        if(b*b>=c*c+a*a){
            return c;
        }
        if(c*c>=b*b+a*a){
            return b;
        }
        double l=(a+b+c)/2;//周长一半
        double area=Math.sqrt(l*(l-a)*(l-b)*(l-c));//海伦公式求面积
        return 2*area/a;
    }
}
