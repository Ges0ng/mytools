package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;

public class PolygonTrans extends UDF {
    /**
     * polygon转换
     * @param str1
     * @return
     * @throws Exception
     */
    public String evaluate(String str1) throws Exception {
        //str1 = "git world!";

        str1 = str1.replace("#",",");
        str1 = str1.replace("MultiPolygon(((", "POLYGON((");
        str1 = str1.replace(")))", "))");

        return str1;
    }
}
