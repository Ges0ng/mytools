package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


public class StringContain extends UDF {
    /**
     * 判断字符串是否包含子字符串
     * @param subStr
     * @param str
     * @return
     * @throws Exception
     */
    public int evaluate(String subStr, String str) throws Exception {
        if(str.contains(subStr)){
            return 1;
        } else {
            return 0;
        }
    }

    public int evaluate(String subStr, String str, String delimiter) throws Exception {
        Set<String> strSet = new HashSet<>(Arrays.asList(str.split(delimiter)));

        if(strSet.contains(subStr)){
            return 1;
        } else {
            return 0;
        }
    }

}
