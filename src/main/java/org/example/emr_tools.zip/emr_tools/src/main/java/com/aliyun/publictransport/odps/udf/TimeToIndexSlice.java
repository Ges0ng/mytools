package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;


public class TimeToIndexSlice extends UDF {
    /**
     * 时间转换为时间片序号
     * @param timeStr
     * @param step
     * @return
     */
    public String  evaluate(String timeStr, Long step) {
        if (timeStr.length() < 12) {
            return null;
        }
        String mm = timeStr.substring(10, 12);
        String hh = timeStr.substring(8, 10);
        return String.valueOf((Integer.valueOf(hh) * 60 + Integer.valueOf(mm)) /step) ;
    }
}