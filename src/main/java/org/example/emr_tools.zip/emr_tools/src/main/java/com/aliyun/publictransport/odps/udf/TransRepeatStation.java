package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;
import org.apache.commons.lang.StringUtils;


import java.util.*;

public class TransRepeatStation extends UDF {
    /**
     * 返回轨交公交重复段站点
     * @param tranship_station "轨交序号1,公交序号1;轨交序号1,公交序号1;..."
     * @return "轨交序号1,轨交序号2...;公交序号1,公交序号2..."
     */
    public String evaluate(String tranship_station){
        List<String> tranship_stations= Arrays.asList(tranship_station.split(";"));
        Collections.sort(tranship_stations, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return Integer.valueOf(o1.split(",")[1])-Integer.valueOf(o2.split(",")[1]);
            }
        });
        List<String> railList=new ArrayList<>();
        List<String> busList=new ArrayList<>();
        int flag=0;
        for (int i=1;i<tranship_stations.size();i++){
            if(Integer.valueOf(tranship_stations.get(i).split(",")[1])-Integer.valueOf(tranship_stations.get(i-1).split(",")[1])<=4){
                if(flag==0){
                    railList.add(tranship_stations.get(i-1).split(",")[0]);
                    busList.add(tranship_stations.get(i-1).split(",")[1]);
                    flag=1;
                }
                railList.add(tranship_stations.get(i).split(",")[0]);
                busList.add(tranship_stations.get(i).split(",")[1]);
            }else {
                flag=0;
            }
        }
        if(busList.size()==0||busList.size()==0){
            return null;
        }
        return StringUtils.join(railList,",")+";"+StringUtils.join(busList,",");
    }

    public static void main(String[] args) {
        System.out.println(new TransRepeatStation().evaluate("11,19;14,24;14,25;7,7;12,21;10,16;10,17;9,13;8,10"));
    }
}
