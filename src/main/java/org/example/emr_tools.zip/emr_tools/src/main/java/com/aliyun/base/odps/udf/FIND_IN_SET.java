package com.aliyun.base.odps.udf;

import com.aliyun.odps.udf.UDF;

import java.util.Arrays;

public class FIND_IN_SET extends UDF {
    public Boolean evaluate(String str,String strs,String separator){
        if (str==null||strs==null){
            return false;
        }
        return  Arrays.asList(strs.split(separator)).contains(str);
    }

    public static void main(String[] args) {
        System.out.println(new FIND_IN_SET().evaluate("a","a,sada,3213,ret",","));
    }
}
