package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ParallelRelationship extends UDF {
    /**
     *
     * @param station "站序1,站序2,..."
     * @return 1平行 2相交 3混合
     */
    public String evaluate(String station){
        Boolean parallelFlag=false;
        Boolean crossFlag=false;
        List<String> list= Arrays.asList(station.split(","));
        Collections.sort(list, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return Integer.valueOf(o1)-Integer.valueOf(o2);
            }
        });
        if (list.size()==1){
            return "2";
        }
        for (int i=1;i<list.size();i++){
            if(Integer.valueOf(list.get(i))-Integer.valueOf(list.get(i-1))<=4){
                parallelFlag=true;
            }else {
                if (i==list.size()-1||i==1||Integer.valueOf(list.get(i+1))-Integer.valueOf(list.get(i))>4){
                    crossFlag=true;
                }
            }
        }
        if(parallelFlag&&crossFlag){
            return "3";
        }
        if (parallelFlag&&!crossFlag){
            return "1";
        }else{
            return "2";
        }
    }

    public static void main(String[] args) {
        System.out.println(new ParallelRelationship().evaluate("1,18,2,20"));
    }
}
