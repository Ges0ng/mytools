package com.aliyun.publictransport.odps.udf;

import com.aliyun.odps.udf.UDF;

import java.awt.geom.Point2D;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PolygonArea extends UDF {
    // 地球半径 - 米
    // 源码中使用半径为 6367460.0;
    private static double earthRadiusMeters = 6371000.0;
    private static double metersPerDegree = 2.0 * Math.PI * earthRadiusMeters / 360.0;
    private static double radiansPerDegree = Math.PI / 180.0;
    private static double degreesPerRadian = 180.0 / Math.PI;

//	/**
//	 * 传入经纬度集合计算面积
//	 * @param points
//	 */
//	private void calculateArea(List<double[]> points) {
//		if (points.size() > 2) {
//			double areaMeters2 = PlanarPolygonAreaMeters2(points);
//			// if (areaMeters2 > 1000000.0) {
//			areaMeters2 = SphericalPolygonAreaMeters2(points);
//			System.out.println("面积为：" + areaMeters2 + "（平方米）");
//			// }
//
//		}
//	}

    /**
     * 球面多边形面积计算
     *
     * @param points
     * @return
     */
    private double SphericalPolygonAreaMeters2(List<double[]> points) {
        double totalAngle = 0.0;
        for (int i = 0; i < points.size(); i++) {
            int j = (i + 1) % points.size();
            int k = (i + 2) % points.size();
            totalAngle += Angle(points.get(i), points.get(j), points.get(k));
        }

        double planarTotalAngle = (points.size() - 2) * 180.0;
        double sphericalExcess = totalAngle - planarTotalAngle;

        if (sphericalExcess > 420.0) {
            totalAngle = points.size() * 360.0 - totalAngle;
            sphericalExcess = totalAngle - planarTotalAngle;
        } else if (sphericalExcess > 300.0 && sphericalExcess < 420.0) {
            sphericalExcess = Math.abs(360.0 - sphericalExcess);
        }

        return sphericalExcess * radiansPerDegree * earthRadiusMeters
                * earthRadiusMeters;
    }

    /**
     * 角度
     *
     * @param p1
     * @param p2
     * @param p3
     * @return
     */
    private double Angle(double[] p1, double[] p2, double[] p3) {
        double bearing21 = Bearing(p2, p1);
        double bearing23 = Bearing(p2, p3);
        double angle = bearing21 - bearing23;
        if (angle < 0.0) {
            angle += 360.0;
        }
        return angle;
    }

    /**
     * 方向
     *
     * @param from
     * @param to
     * @return
     */
    private double Bearing(double[] from, double[] to) {
        double lat1 = from[1] * radiansPerDegree;
        double lon1 = from[0] * radiansPerDegree;
        double lat2 = to[1] * radiansPerDegree;
        double lon2 = to[0] * radiansPerDegree;
        double angle = -Math.atan2(
                Math.sin(lon1 - lon2) * Math.cos(lat2),
                Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1)
                        * Math.cos(lat2) * Math.cos(lon1 - lon2));
        if (angle < 0.0) {
            angle += Math.PI * 2.0;
        }
        angle = angle * degreesPerRadian;
        return angle;
    }

    /***
     * 计算平面多边形面积
     *
     * @param polygon
     *            Point2D.Double
     * @return
     * */
    public Double evaluate(String polygon) {
        List<ArrayList<Double>> points = new ArrayList<>();
        polygon=polygon.replace("MULTIPOLYGON(((","").replace(")))","").replace(")),((",",");
        String[] s1 = polygon.split(",");
        for (String ss : s1) {
            String[] temp = ss.split(" ");
//            Point2D.Double point = new Point2D.Double(java.lang.Double.parseDouble(temp[0]),
//                    java.lang.Double.parseDouble(temp[1]));
            ArrayList<Double> point=new ArrayList<>();
            if (temp.length==2){
                point.add(Double.parseDouble(temp[0]));
                point.add(Double.parseDouble(temp[1]));
            }else {
                return null;
            }

            points.add(point);
//            System.out.println(temp[1] + "," + temp[0]);
        }
        double a = 0.0;
        if(points.size() > 2){
            for (int i = 0; i < points.size(); ++i) {
                int j = (i + 1) % points.size();
                double xi = points.get(i).get(0) * metersPerDegree
                        * Math.cos(points.get(i).get(1) * radiansPerDegree);
                double yi = points.get(i).get(1) * metersPerDegree;
                double xj = points.get(j).get(0) * metersPerDegree
                        * Math.cos(points.get(j).get(1) * radiansPerDegree);
                double yj = points.get(j).get(1) * metersPerDegree;
                a += xi * yj - xj * yi;
            }
        }
        a = Math.ceil(BigDecimal.valueOf(Math.abs(a / 2.0)).setScale(1,BigDecimal.ROUND_DOWN).doubleValue());
        return a;
    }
}
